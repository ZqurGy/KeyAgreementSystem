// DBTest.cpp: 定义控制台应用程序的入口点。
//
#include <iostream>
#include <occi.h>
using namespace std;
using namespace oracle::occi;

int main()
{
	const string userName = "SCOTT";
	const string password = "tiger";
	const string connString = "192.168.247.129:1521/orcl";
	try
	{
		Environment *env = Environment::createEnvironment(Environment::DEFAULT);
		Connection *con = env->createConnection(userName, password, connString);
		cout << "Success to connect!" << endl;
		Statement *stmt = con->createStatement();
		stmt->setSQL("select * from emp");
		ResultSet *rs = stmt->executeQuery();
		while (rs->next())
		{
			cout << "ID:" << endl;
		}
		con->terminateStatement(stmt);
		env->terminateConnection(con);
		Environment::terminateEnvironment(env);
	}
	catch (SQLException &ex)
	{
		cout << ex.what() << endl;
	}

//	system("pause");
	return 0;
}

